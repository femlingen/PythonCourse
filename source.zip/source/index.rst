.. Cardlib documentation master file, created by
   sphinx-quickstart on Sat Feb 23 17:47:28 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

*Welcome to cardpy, hope you enjoy using our module*
*With this module you can use a deck of cards and create hands with the afformentioned cards*

Welcome to Cardlib's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
.. automodule:: cardlib
   :members:
   :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

